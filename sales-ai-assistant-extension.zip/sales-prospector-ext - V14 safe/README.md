# sales-prospector-ext
Chrome extension for sales prospecting
