(async function(){
  const els = {
    apiKey: document.getElementById('apiKey'),
    model:  document.getElementById('model'),
    save:   document.getElementById('save'),
    status: document.getElementById('status'),
    where:  document.getElementById('where'),
      vendor: document.getElementById("vendorContainer"),
      
        debug:  document.getElementById('debug_logs'),


          remote_enabled:  document.getElementById('remote_enabled'),
  remote_companyId:document.getElementById('remote_companyId'),
  remote_endpoint: document.getElementById('remote_endpoint'),
  remote_token:    document.getElementById('remote_token'),
  supabase_url:  document.getElementById('supabase_url'),
supabase_anon: document.getElementById('supabase_anon'),
supabase_token:document.getElementById('supabase_token'),
pair_code:       document.getElementById('pair_code'),
btn_pair_claim:  document.getElementById('btn_pair_claim'),



    
  };





  
  // --- Vendor defaults + helpers ---
const DEFAULT_VENDOR = {
  name: "Your company",
  pitch: "What do you sell",
  valueProps: ["Value proposition"],
  outcomes: ["Your product/Service business result"],
  customerExamples: ["Your clients"],
  industryHint: "Industry"
};

function splitLines(v) {
  return (v || "").split(/\r?\n/).map(s => s.trim()).filter(Boolean);
}

function vendorFromForm() {
  return {
    name:             (document.getElementById("vendor_name")?.value || "").trim(),
    pitch:            (document.getElementById("vendor_pitch")?.value || "").trim(),
    valueProps:       splitLines(document.getElementById("vendor_valueProps")?.value || ""),
    outcomes:         splitLines(document.getElementById("vendor_outcomes")?.value || ""),
    customerExamples: splitLines(document.getElementById("vendor_customerExamples")?.value || ""),
    industryHint:     (document.getElementById("vendor_industry")?.value || "").trim()
  };
}

function renderVendorForm(vendor = DEFAULT_VENDOR) {
    els.vendor.innerHTML = `

    <style>
      .card{background:#121935;border:1px solid rgba(255,255,255,.12);border-radius:16px;padding:16px;margin:16px 0}
      .grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
      .full{grid-column:1 / -1}
      label{font-size:12px;font-weight:800;color:#c9d7ff;display:block;margin:8px 0 6px}
      input,textarea{width:100%;box-sizing:border-box;border-radius:10px;border:1px solid rgba(255,255,255,.12);
        background:rgba(255,255,255,.05);color:#fff;padding:10px;font-size:14px}
      textarea{min-height:90px}
      small{display:block;opacity:.8;margin-top:6px}
      h2{margin:0 0 10px;font-size:18px}
    </style>

    <div class="card">
      <h2>Vendor Profile for Lawrence</h2>
      <div class="grid">
        <div>
          <label>Your company</label>
          <input id="vendor_name" placeholder="e.g., Acme Analytics" />
          <small>Used when Lawrence names your solution.</small>
        </div>
        <div>
          <label>Industry</label>
          <input id="vendor_industry" placeholder="e.g., HR services, FinTech, Healthcare" />
          <small>Guides phrasing (no guessing).</small>
        </div>

        <div class="full">
          <label>What do you sell</label>
          <input id="vendor_pitch" placeholder="e.g., Workforce augmentation and managed HR services" />
          <small>1 line; used once in emails/briefs.</small>
        </div>

        <div>
          <label>Value proposition <small>(one per line)</small></label>
          <textarea id="vendor_valueProps" placeholder="Identify bottlenecks&#10;Optimize onboarding&#10;Measure experiments"></textarea>
          <small>Lawrence may reference up to 2.</small>
        </div>
        <div>
          <label>Your product/Service business result <small>(one per line)</small></label>
          <textarea id="vendor_outcomes" placeholder="Increase conversion&#10;Improve retention&#10;Reduce time-to-value"></textarea>
          <small>Used to tie outcomes to the prospect.</small>
        </div>

        <div class="full">
          <label>Your clients <small>(one per line)</small></label>
          <textarea id="vendor_customerExamples" placeholder="Only names you’re happy to reference"></textarea>
          <small>If empty, Lawrence uses safe generic phrasing.</small>
        </div>
      </div>
    </div>
  `;

  // fill values
  document.getElementById("vendor_name").value               = vendor.name || "";
  document.getElementById("vendor_pitch").value              = vendor.pitch || "";
  document.getElementById("vendor_valueProps").value         = (vendor.valueProps || []).join("\n");
  document.getElementById("vendor_outcomes").value           = (vendor.outcomes || []).join("\n");
  document.getElementById("vendor_customerExamples").value   = (vendor.customerExamples || []).join("\n");
  document.getElementById("vendor_industry").value           = vendor.industryHint || "";
}


  async function load() {
    // Try sync then local so we reflect whichever exists
    let source = "empty";
    try {
      const s = await chrome.storage.sync.get(['openai_key','openai_model','apiKey','model']);
      if (s.openai_key || s.apiKey) {
        els.apiKey.value = (s.openai_key || s.apiKey || '').trim();
        els.model.value  = (s.openai_model || s.model || 'gpt-4o-mini').trim();
        source = "sync";
      } else {
        const l = await chrome.storage.local.get(['openai_key','openai_model','apiKey','model']);
        els.apiKey.value = (l.openai_key || l.apiKey || '').trim();
        els.model.value  = (l.openai_model || l.model || 'gpt-4o-mini').trim();
        source = (l.openai_key || l.apiKey) ? "local" : "empty";
      }
    } catch {
      els.status.textContent = 'Failed to load settings.';
      els.status.className = 'err';
    }
    els.where.textContent = `Loaded from: ${source}`;

    // Load debug + remote config from sync
    try {
      const s2 = await chrome.storage.sync.get(['debug_logs','remote_enabled','remote_companyId','remote_endpoint','remote_token','vendor_schema_version']);
      if (typeof s2.debug_logs === 'boolean') els.debug.checked = s2.debug_logs;

      els.remote_enabled.checked   = !!s2.remote_enabled;
      els.remote_companyId.value   = (s2.remote_companyId || "");
      els.remote_endpoint.value    = (s2.remote_endpoint || "");
      els.remote_token.value       = (s2.remote_token || "");

      // Show schema version in console for quick QA
      console.log('[Options] vendor schema version:', s2.vendor_schema_version || '(unset)');
      // Load Supabase fields
try {
  const s3 = await chrome.storage.sync.get(['supabase_url','supabase_anon','supabase_token']);
  if (s3.supabase_url)  els.supabase_url.value  = s3.supabase_url;
  if (s3.supabase_anon) els.supabase_anon.value = s3.supabase_anon;
  if (s3.supabase_token)els.supabase_token.value= s3.supabase_token;
} catch {}

    } catch {}


        // Load debug flag (sync only)
    try {
      const { debug_logs } = await chrome.storage.sync.get('debug_logs');
      if (typeof debug_logs === 'boolean') els.debug.checked = debug_logs;
    } catch {}

  }

  await load();


  try {
  const snap = await chrome.storage.sync.get(null);
  console.log('[Options] storage snapshot keys:', Object.keys(snap));
} catch {}



  // Wire the "Claim code" button
  if (els.btn_pair_claim) {
    els.btn_pair_claim.addEventListener('click', claimPairCode);
  }


  // ---- Pair claim (fetch token using 6-digit code) ----
  async function claimPairCode() {
    // Read Supabase URL + anon from the form (we save them on Save)
    const supabase_url  = (els.supabase_url.value || '').trim().replace(/\/+$/,'');
    const supabase_anon = (els.supabase_anon.value || '').trim();

    if (!supabase_url || !supabase_anon) {
      els.status.textContent = 'Please fill Supabase URL and anon key first, then try again.';
      els.status.className = 'err';
      return;
    }

    // Normalize code: "123-456" -> "123456"
    const raw = String(els.pair_code.value || '').replace(/[^0-9]/g,'').slice(0,6);
    if (raw.length !== 6) {
      els.status.textContent = 'Enter a 6-digit code (e.g., 123-456).';
      els.status.className = 'err';
      return;
    }

    try {
      // 1) Read the pairing row (valid + not claimed)
      const headers = { 'apikey': supabase_anon, 'Content-Type': 'application/json' };
      headers['Authorization'] = `Bearer ${supabase_anon}`;

      // NOTE: use `raw` (the 6-digit code you normalized), and include refresh_token in the select
      // Use the sanitized 6-digit string (raw) and fetch refresh_token too
const url = `${supabase_url}/rest/v1/pairing_codes?code=eq.${raw}&select=access_token,refresh_token,code,claimed,expires_at&limit=1`;



      
      
      
      const res = await fetch(url, { headers });
      if (!res.ok) throw new Error('Code not found or expired.');
      const rows = await res.json();
      const row = rows && rows[0];
      if (!row || row.claimed) throw new Error('Code invalid or already claimed.');

      // 2) Save token locally so background.js can use it (RLS)
      const token = row.access_token || '';
      const refresh = row.refresh_token || '';
      await chrome.storage.sync.set({ supabase_token: token, supabase_refresh: refresh });


      
      // 3) Mark code claimed=true (best-effort)
// Only do this if a privileged token is available; anon key alone often 401s.
try {
  const { extension_access_token } = await chrome.storage.sync.get('extension_access_token');
  if (extension_access_token) {
    await fetch(`${supabase_url}/rest/v1/pairing_codes?code=eq.${raw}`, {
      method: 'PATCH',
      headers: {
        'apikey': supabase_anon,
        'Authorization': `Bearer ${extension_access_token}`,
        'Content-Type': 'application/json',
        'Prefer': 'return=minimal'
      },
      body: JSON.stringify({ claimed: true })
    });
  } else {
    if (window?.localStorage?.getItem('debug_claim_patch') === '1') {
  console.warn('[Options] Skipping PATCH claimed=true (no privileged token available)');
}

  }
} catch (e) {
  console.warn('[Options] PATCH claimed=true failed:', e);
}


      els.status.textContent = 'Paired! Token saved. Click "Save" to persist all settings.';
      els.status.className = 'ok';
    } catch (e) {
      console.error('[Pair]', e);
      els.status.textContent = 'Could not claim code: ' + (e?.message || e);
      els.status.className = 'err';
    }
  }


  const saved = await chrome.storage.sync.get("vendor_config");
  const vendor = (saved?.vendor_config?.vendor) || saved?.vendor_config || DEFAULT_VENDOR;
  renderVendorForm(vendor);


  els.save.addEventListener('click', async () => {
    const key = els.apiKey.value.trim();
    const model = els.model.value;

    try {
      await chrome.storage.sync.set({ openai_key: key, openai_model: model });

      // Save remote config controls
await chrome.storage.sync.set({
  remote_enabled:   !!els.remote_enabled.checked,
  remote_companyId: els.remote_companyId.value.trim(),
  remote_endpoint:  els.remote_endpoint.value.trim(),
  remote_token:     els.remote_token.value.trim()
});

// Save Supabase fields (don’t overwrite token if field is empty)
await chrome.storage.sync.set({
  supabase_url:  els.supabase_url.value.trim(),
  supabase_anon: els.supabase_anon.value.trim()
});

const _tok = (els.supabase_token.value || '').trim();
if (_tok) {
  await chrome.storage.sync.set({ supabase_token: _tok });
}




      // Save Debug flag (sync)
await chrome.storage.sync.set({ debug_logs: !!els.debug.checked });


  // Also persist the Vendor Profile for Lawrence
  const vendor_config = { vendor: vendorFromForm() };
  await chrome.storage.sync.set({ vendor_config });


      els.status.textContent = 'Saved!';
      els.status.className = 'ok';
      els.where.textContent = 'Saved to: sync';
      setTimeout(()=>{ els.status.textContent=''; els.status.className=''; }, 1200);
    } catch {
      els.status.textContent = 'Save failed.';
      els.status.className = 'err';
    }
  });
})();
