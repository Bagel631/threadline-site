// prompts.js (module)
import {
  ensureSettingsLoaded,
  readSupabaseConfig,
  readVendorFromStorage,
  userOptions,
  OPENAI_TTS_MODEL,
  OPENAI_TTS_VOICE,
  firstNameOf
} from "./background.js";

// local cache for vendor JSON string (used only for system message composition)
let _vendorBlockCache = "";








export async function withVendorPrompt(system = "", user = "") {

  const v = await readVendorFromStorage();
  const clamp = (a, n=3) => (Array.isArray(a) ? a.map(s=>String(s).trim()).filter(Boolean).slice(0,n) : []);
  const vendorBlock = {
    name: v.name || "",
    website: v.website || "",
    pitch: String(v.pitch || "").slice(0, 400),
    value_props: clamp(v.valueProps),
    outcomes: clamp(v.outcomes),
    personas: clamp(v.personas),
    pains: clamp(v.painPoints),
    integrations: clamp(v.integrations),
    proof_points: clamp(v.proofPoints),
    case_studies: clamp(v.caseStudies),
    tone: v.tone || "Professional",
    cta_preference: v.ctaPreference || "Book a demo",
    booking_url: v.bookingUrl || "",
    signature: String(v.signature || "").slice(0, 800),
    industry: v.industryHint || ""
  };
  _vendorBlockCache = JSON.stringify(vendorBlock);
  const sys = [
    system,
    "",
    "CRITICAL VENDOR CONTEXT (ground truth; never ask the user for these fields):",
    _vendorBlockCache
  ].join("\n");
  return { sys, usr: user };
}


export async function callOpenAIJSON({ system, user, parseFallback = {}, temperature = 0 }) {


  await ensureSettingsLoaded();
  const { sys, usr } = await withVendorPrompt(system, user);

  

    const payload = (() => {
    // build messages
    const msgs = [
      { role: "system", content: sys },
      { role: "user",   content: usr }
    ];

    // --- CRITICAL FIX: ensure 'json' (lowercase) appears in messages ---
    const joined = `${sys}\n${usr}`.toLowerCase();
    if (!joined.includes('json')) {
      msgs.unshift({ role: "system", content: "json" });
    }

    return {
      model: userOptions.model || "gpt-4o-mini",
      temperature,
      messages: msgs,
      response_format: { type: "json_object" }
    };
  })();


  const { url: supaUrl, anon, token } = await readSupabaseConfig();
  console.log("[DBG] payload", payload);

const url = `${supaUrl}/functions/v1/ai-json`;
const headers = {
  "Content-Type": "application/json",
  "apikey": anon,
  // allow either paired (user token) or anonymous (falls back to anon)
  "Authorization": `Bearer ${token || anon}`
};
console.log("[BG] callOpenAIJSON headers:", headers);

// ...




  const MAX_ATTEMPTS = 3;
  const RETRY_STATUS = new Set([429, 500, 502, 503, 504]);

  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    const ctrl = new AbortController();
    const tid = setTimeout(() => ctrl.abort(), 45000); // 45s per attempt (peers can be slow)

    let res;
    try {
      res = await fetch(url, { method: "POST", headers, body: JSON.stringify(payload), signal: ctrl.signal });
    } catch (e) {
      clearTimeout(tid);
      console.error("[BG] OpenAI network error:", e);
      if (attempt < MAX_ATTEMPTS) {
        await new Promise(r => setTimeout(r, 600 * attempt));
        continue;
      }
      return parseFallback;
    }

    clearTimeout(tid);

    if (!res.ok) {
      let body = "";
      try { body = await res.text(); } catch {}
      console.error("[BG] OpenAI error", res.status, body);

      if (RETRY_STATUS.has(res.status) && attempt < MAX_ATTEMPTS) {
        await new Promise(r => setTimeout(r, 700 * attempt));
        continue;
      }
      return parseFallback;
    }

    try {
      const data = await res.json();
      const text = data?.choices?.[0]?.message?.content || "";
      // Be lenient: extract the first JSON object even if the model wrapped it.
let raw = text.trim();
// strip ```json fences if present
const fenced = raw.match(/```json([\s\S]*?)```/i);
if (fenced) raw = fenced[1].trim();
// grab the first {...} block
const m = raw.match(/\{[\s\S]*\}$/);
if (m) raw = m[0];

      return JSON.parse(raw);

    } catch (e) {
      console.warn("[BG] Failed parsing OpenAI JSON:", e);
      return parseFallback;
    }
  }

  return parseFallback;
}


export async function openaiTTS(text, { model = OPENAI_TTS_MODEL, voice = OPENAI_TTS_VOICE } = {}) {

  await ensureSettingsLoaded();
const { url: supaUrl, anon, token } = await readSupabaseConfig();

const res = await fetch(`${supaUrl}/functions/v1/tts`, {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "apikey": anon,
    "Authorization": `Bearer ${token || anon}`
  },
  body: JSON.stringify({
    text: String(text || "").slice(0, 4000),
    model,
    voice
  })
});

console.log("[DBG] response status", res.status);
console.log("[DBG] response headers", [...res.headers.entries()]);
console.log("[DBG] response raw", await res.clone().text());

if (!res.ok) {
  const t = await res.text().catch(()=>String(res.status));
  throw new Error(`TTS failed: ${res.status} ${t}`);
}
const { audioB64 } = await res.json();
return audioB64;

}







export async function gptBuildNewsQueries({ company, mode = "financial", instruction = "" }) {

  // modes: financial, product, hiring, risk, exec, partnerships, generic
  const system = [
    "You generate Google Web search queries (for google.com/search).",
    "Return strictly JSON: {\"queries\":[\"...\"]}.",
    "Each query must be short, precise, and likely to surface Top Stories.",
    "Honor user instruction exactly (site:, AND/OR, quoted phrases, time hints).",
    "No markdown. No commentary."
  ].join("\n");

  const user = `
Company: ${company}
Mode: ${mode}
UserInstruction: ${instruction || "(none)"}

Rules:
- 3 to 6 queries only.
- Use quoted company name when helpful.
- Prefer boolean operators (AND/OR) and site: filters if relevant.
- Avoid filler like "latest" or "news".
- Assume search will open google.com/search (not Google News RSS).
`.trim();

  const out = await callOpenAIJSON({
    system, user,
    parseFallback: { queries: [] }
  });

  // robust fallback if AI returns nothing
  if (!Array.isArray(out.queries) || out.queries.length === 0) {
    const fallback = {
      financial: [
        `"${company}" earnings OR results OR revenue OR guidance`,
        `"${company}" profit OR loss OR outlook`,
        `"${company}" funding OR acquisition OR IPO OR merger`
      ],
      product: [
        `"${company}" product launch OR feature OR AI`,
        `"${company}" roadmap OR release OR update`,
        `"${company}" integration OR partnership`
      ],
      generic: [
        `"${company}" announcement`,
        `"${company}" interview OR CEO`,
        `"${company}" partnership OR expansion`
      ]
    };
    return fallback[mode] || fallback.generic;
  }

  return out.queries.slice(0, 6);
}














export async function gptSummarizeHeadlines(items = [], company = "") {

  if (!Array.isArray(items) || items.length === 0) {

    return items.map(() => "");
  }

  const system = [
    "You are a news desk assistant.",
    "Given headlines about a target company, write one neutral summary for each, 18–28 words.",
    'Return strictly JSON: {"summaries":["..."]}.',
    "Plain text only. No Markdown."
  ].join("\n");

  const user = JSON.stringify({
    company,
    headlines: items.map(it => it.title).slice(0, 8)
  });

  const out = await callOpenAIJSON({
    system,
    user,
    parseFallback: { summaries: [] }
  });

  const arr = Array.isArray(out.summaries) ? out.summaries : [];
  return items.map((_, i) => (typeof arr[i] === "string" ? arr[i] : ""));
}




// Summarize one company-related headline and prefer a direct article link
export async function gptNewsSummary({ company = "", headline = "", link = "" } = {}) {

  const url = link || "https://www.google.com/search?q=" + encodeURIComponent((company ? company + " " : "") + headline);
  if (!headline) return { summary: "", url };


  const system = [
    "You write careful, neutral news abstracts.",
    "You DO NOT have web access. Do not claim to have read the article.",
    "Return strictly JSON: {\"summary\":\"...\"}.",
    "If the headline lacks context, say what's likely, note uncertainty, and keep it concise."
  ].join("\n");

  const user = `
Company: ${company}
Headline: ${headline}

Task:
- Write 2 short paragraphs (max ~120 words total).
- Base only on the headline and widely known context; avoid fabricating specifics.
- If uncertain, state that clearly.
`.trim();

  const out = await callOpenAIJSON({
    system,
    user,
    parseFallback: { summary: "" }
  });

  return { summary: out.summary || "", url };
}









export async function gptResponsibilitiesRich({ role = "", company = "", background = [] } = {}) {

  if (!role) return "";


  // Use your saved vendor profile so the analysis is industry-aware
  const v = await readVendorFromStorage();

  const system = [
    "You are a sales intelligence analyst.",
    "Return strictly JSON: {\"text\":\"...\"} where `text` is the FULL response.",
    "PLAIN TEXT ONLY — no Markdown, no asterisks, no bold, no headers.",
    "Insert ONE BLANK LINE between each numbered item.",
    "Keep it concise, scannable, and prioritized for " + (v.industryHint || "the vendor’s industry") + " relevance."
  ].join("\n");

  const user = `
You analyze a person's likely job responsibilities to assess buying influence for "${v.name || "our solution"}".

Inputs:
- Job Title: ${role}
- Company: ${company}
- Previous Experience (most recent first):
${Array.isArray(background) && background.length ? background.map((l,i)=>`${i+1}. ${l}`).join("\n") : "None provided"}
- Vendor context:
  • What we sell: ${v.pitch || "—"}
  • Value props: ${(v.valueProps || []).slice(0,5).join("; ") || "—"}
  • Outcomes: ${(v.outcomes || []).slice(0,5).join("; ") || "—"}
  • Industry hint: ${v.industryHint || "—"}

Instructions:
- Output exactly 3 specific, concrete responsibilities this person is likely to have, ordered by relevance to the vendor context.
- Keep each line short and scannable (max ~14 words). No confidence flags, no “Guess”.
- PLAIN TEXT ONLY. ONE BLANK LINE between items.
`.trim();

  const out = await callOpenAIJSON({
    system,
    user,
    parseFallback: { text: "" }
  });

  return typeof out.text === "string" ? out.text : "";
}












// AI Fit Summary from responsibilities text
export async function gptFitSummaryFromResponsibilities({ responsibilities = "", role = "", company = "" } = {}) {

  if (!responsibilities) {
    return { fitLevel: "", confidence: 0, reasoning: "", notes: "", summaryLine: "" };
  }

  const system = [
    "You are a B2B sales intelligence expert.",
    "Return strictly JSON with these fields:",
    '{"fitLevel":"Low|Medium|High","confidence":NUMBER,"reasoning":"...","notes":"...","summaryLine":"Fit: [Low/Medium/High] -> Reasoning: ..."}',
    "Plain text only (no Markdown)."
  ].join("\n");

  const user = [
    "Evaluate whether the person is a potential buyer for a product or service based on their job responsibilities.",
    "Follow the rules:",
    "1) Decide if they have buying authority, influence, or budget control.",
    '2) Classify fit: Low | Medium | High. Be conservative: only use "High" with clear buying authority and budget control; otherwise choose "Medium" or "Low".',
    "3) Explain WHY using evidence from responsibilities.",
    "4) Clarify if this is strong reasoning or educated guessing.",
    "5) End with a clear summary statement as: Fit: [Level] → Reasoning: ...",
    "",
    `Role: ${role}`,
    `Company: ${company}`,
    "",
    "Job Responsibilities:",
    responsibilities
  ].join("\n");

  const out = await callOpenAIJSON({
    system,
    user,
    parseFallback: { fitLevel: "", confidence: 0, reasoning: "", notes: "", summaryLine: "" }
  });

  // Normalize types
  const lvl = (out.fitLevel || "").trim();
  return {
    fitLevel: lvl,
    confidence: Number(out.confidence || 0),
    reasoning: (out.reasoning || "").trim(),
    notes: (out.notes || "").trim(),
    summaryLine: (out.summaryLine || "").trim()
  };
}












// Extract insights from recent LinkedIn activity (posts user wrote/shared/liked)
export async function gptInsights(posts = [], profile = {}) {

    const v = await readVendorFromStorage();

  if (!Array.isArray(posts) || posts.length === 0) return [];
  const trimmed = posts.slice(0, 15);

  const system = [
    "You analyze a person's LinkedIn activity, including comments, likes, reposts, shares and others. All linkedin activity.",
    "Return up to 4 concrete insights about themes, posts commented, interests, tools, or markets they care about. Organize them in timestamp order",
    "Each bullet must be <= 18 words, neutral and specific. Do not invent facts not evident from snippets.",
    "Output JSON strictly as {\"items\":[\"...\",\"...\"]}.",
    "If profile/company context is broad, prefer insights that are relevant to: " + (v.industryHint || "the seller's industry") + "."

  ].join("\n");

  const user = JSON.stringify({
    profile: {
      name:  profile?.name  || "",
      role:  profile?.role  || "",
      company: profile?.company || ""
    },
    activity_snippets: trimmed
  });

  const out = await callOpenAIJSON({ system, user, parseFallback: { items: [] } });
  return Array.isArray(out.items) ? out.items.filter(Boolean).slice(0, 4) : [];
}










/**
 * Prospecting email generator (vendor-agnostic, role-tailored, industry-safe peers, clear CTA)
 *
 * inputs.vendor is optional and can include:
 * {
 *   name: "Amplitude",                            // or any vendor; defaults to "our platform"
 *   pitch: "a product analytics platform...",     // one short phrase used once
 *   valueProps: ["identify friction", "optimize adoption", "measure impact"], // bullets/phrases
 *   outcomes: ["conversion", "retention"],        // business outcomes to reference
 *   customerExamples: ["Tesco", "Sainsbury's"],   // ONLY these may be name-dropped
 *   industryHint: "UK grocery retail"             // helps choose category phrasing if examples absent
 * }
 */
export async function gptEmail({ profile = {}, inputs = {}, tone = "Professional" } = {}) {

  

  const { name = "", role = "", company = "", location = "" } = profile || {};
  const firstName = firstNameOf(name);

  const {
    responsibilities = [],
    insights = [],
    news = [],
    financial = [],
    background = [],
    vendor = {}
  } = inputs || {};

  const vendorName = (vendor.name || "").trim();
  const vendorPitch = (vendor.pitch || "a platform that helps teams identify bottlenecks, optimize journeys, and measure impact").trim();
  const valueProps = Array.isArray(vendor.valueProps) && vendor.valueProps.length
    ? vendor.valueProps.slice(0, 5)
    : ["identify friction", "optimize adoption", "improve retention", "measure impact", "align teams on product KPIs"];
  const outcomes = Array.isArray(vendor.outcomes) && vendor.outcomes.length
    ? vendor.outcomes.slice(0, 5)
    : ["conversion", "retention", "time-to-value"];
  const customerExamples = Array.isArray(vendor.customerExamples) ? vendor.customerExamples.slice(0, 4) : [];
  const industryHint = (vendor.industryHint || "").trim();
  const website     = (vendor.website || "").trim();
const bookingUrl  = (vendor.bookingUrl || "").trim();
const ctaPref     = (vendor.ctaPreference || "Book a demo").trim();
const signature   = (vendor.signature || "").trim();


  // ---- System prompt: JSON-only, role-tailored, peer-safe, clear CTA ----
  const system = [
    "You are a senior SDR writing a concise, friendly first-touch prospecting email.",
    "Return strictly JSON: {\"email\":\"...\"}. No other fields. No markdown. No emojis.",
    "Length: 120–150 words total.",
    "Tone: " + tone + ", clear, specific, value-led.",
    "Personalization rules:",
    "- Start with `${firstName},` (use 'Hi there,' if empty).",
    "- Derive the opening problem statement from the provided responsibilities, news, and financial signals for the prospect’s role at their current company.",
    "- If responsibility signals are thin/uncertain, use cautious phrasing (e.g., 'is it fair to say your focus includes…').",
    "Peer example rules (CRITICAL):",
    "- Only reference peer companies included in user-provided customerExamples.",
    "- If NONE are provided, DO NOT guess names; instead use category phrasing like 'other leaders in " + (industryHint || "your industry") + "'.",
    "- Never mention FanDuel, Betclic, Atlassian, PayPal, or any brand unless it appears in customerExamples.",
    "Vendor rules:",
    "- Refer to the offering as " + (vendorName ? vendorName : "our platform") + " and one short pitch once: \"" + vendorPitch + "\".",
    "- Emphasize up to 2 value props from the provided list and tie them to outcomes.",
    "CTA rules (CRITICAL):",
    "- Use this CTA preference verbatim in the closing ask: " + ctaPref + ".",
"- If a booking URL is provided, include it in the CTA once: " + (bookingUrl || "(none)") + ".",
"- If a website is provided, include it once as a reference in the body: " + (website || "(none)") + ".",
"- End the email with this signature block exactly if provided (after 'Best,'): " + (signature ? JSON.stringify(signature) : "\"\"") + ".",
    "- End with ONE clear, friendly, time-bound ask for a 15–20 minute call next week (offer two options), or invite a referral if they’re not the right person.",
    "- Example CTA style: 'Open to 15 minutes Tue or Wed afternoon next week?'",
    "Other constraints:",
    "- No placeholders like [Name]. Use the provided first name string.",
    "- Do not claim you read full articles; base on signals only.",
    "- Do not invent metrics, tools, or customers.",
    "- Close with 'Best,' (no signature block)."
  ].join("\n");

  // ---- User payload: all the signals we have ----
  const user = JSON.stringify({
    profile: {
      firstName,
      fullName: name,
      role,
      company,
      location
    },
    signals: {
      responsibilities,  // free text list or single string
      insights,          // short bullets about interests/activity
      news,              // headlines list (strings)
      financial,         // financial headlines (strings)
      background         // career lines
    },
    vendor: {
      name: vendorName || "our platform",
      pitch: vendorPitch,
      valueProps,
      outcomes,
      customerExamples,  // <- only safe names to reference
      industryHint       // <- helps with category phrasing
    }
  });

  const out = await callOpenAIJSON({
    system,
    user,
    parseFallback: { email: "" }
  });


let body = String(out.email || "").trim();

// — Normalize escaped characters to real newlines/tabs —
body = body
  .replace(/\r/g, "")
  .replace(/\\n/g, "\n")
  .replace(/\\t/g, "\t")
  .replace(/\n{3,}/g, "\n\n"); // collapse 3+ blank lines


// Ensure website present once
if (website && !/https?:\/\//i.test(website) && !body.includes(website)) {
  body += `\n\nMore about us: ${website}`;
} else if (website && !body.includes(website)) {
  body += `\n\nMore about us: ${website}`;
}

// Ensure booking URL present once
if (bookingUrl && !body.includes(bookingUrl)) {
  body += `\n\nQuick scheduling link: ${bookingUrl}`;
}

// Ensure signature appended after "Best," style closing if signature exists
const safeSignature = signature ? String(signature).replace(/\\n/g, "\n").trim() : "";
if (safeSignature && !body.includes(safeSignature)) {
  if (!/(\n|^)Best,/.test(body)) body += `\n\nBest,`;
  body += `\n${safeSignature}`;
}


out.email = body;



  return out.email || "";
  

}













// ---- Vendor-aware Action Plan (paragraph + 3–5 bullets + CTA line) ----

export async function gptActionPlan({ profile = {}, inputs = {}, fitBadge = "" } = {}) {

  await ensureSettingsLoaded();

  const system = [
  "You are a senior B2B sales strategist, you are always explaining the action plan on how to sell to this prospect, if this is not a good buyer, then reference that. never talk as the vendor, but always as your are explaining to the vendor. Return STRICT JSON only.",
  "The system includes a CRITICAL VENDOR CONTEXT JSON block (ground truth).",
  "Vendor JSON is authoritative. Never ask for vendor fields. Never invent customers.",
  "",
  "Your job: craft a short rationale paragraph + 3–5 very tactical next steps + one CTA sentence.",
  "Audience is the seller (the vendor team), not the prospect. Never address the prospect directly. No greetings, no 'let’s', no scheduling language, no sign-offs. Write in third-person (about the prospect) and imperative bullets for the seller.",
  "Fuse vendor value_props → outcomes with THIS prospect’s role, responsibilities, posts/news, and company context.",
  "Be decisive but honest about uncertainty; if the contact is not the buyer, include a referral/multithread step.",
  "",
  "Bullets quality bar (principles, not templates):",
  "- Each bullet starts with a strong verb and is 10–16 words.",
  "- At least one bullet targets referral or multithreading to titles in vendor.personas when buyer mismatch.",
  "- At least one bullet leverages vendor.integrations OR vendor.proof_points/case_studies (only those provided).",
  "- At least one bullet asks a crisp discovery question tied to their role/company signals.",
  "- No fluff, no emojis, no claims of reading full articles.",
  "",
  "CTA is an internal next step for the seller (e.g., 'map stakeholders', 'prep a 15-min discovery outline'), not a message to the prospect. One sentence. Text only.",
  "If vendor.booking_url exists, you MAY include it inline as plain text in the CTA sentence.",
  "",
  "Output JSON exactly:",
  "{",
  '  "paragraph": "80–120 words tying the vendor offer to this prospect/company. Plain text only.",',
  '  "bullets": ["3–5 concrete next steps, each 10–16 words"],',
  '  "cta_line": "≤ 140 chars, friendly, time-bound, single sentence (text only)"',
  "}",
  "",
  "Self-check before answering:",
  "- Paragraph references a specific prospect cue (role, responsibility, post, news) and vendor value_props→outcomes.",
  "- Bullets follow the quality bar and include referral/multithread when appropriate.",
  "- CTA uses vendor.cta_preference and includes booking_url if present.",
  "- Never invent customers; only use proof_points/case_studies that exist in vendor JSON."
].join("\n");


  const user = JSON.stringify({
    fit_badge: fitBadge || "",
    profile: {
      name: profile?.name || "",
      role: profile?.role || "",
      company: profile?.company || "",
      location: profile?.location || ""
    },
    signals: {
      responsibilities: inputs?.responsibilities || "",
      insights: Array.isArray(inputs?.insights) ? inputs.insights.slice(0, 10) : [],
      news: Array.isArray(inputs?.news) ? inputs.news.slice(0, 8) : [],
      financial: Array.isArray(inputs?.financial) ? inputs.financial.slice(0, 8) : [],
      background: Array.isArray(inputs?.background) ? inputs.background.slice(0, 12) : []
    }
  });

  const out = await callOpenAIJSON({
    system,
    user,
    parseFallback: { paragraph: "", bullets: [], cta_line: "" },
    temperature: 0.15
  });

  return {
    paragraph: String(out?.paragraph || ""),
    bullets: Array.isArray(out?.bullets) ? out.bullets : [],
    cta_line: String(out?.cta_line || "")
  };
}







// ---- Prospect & Account 2-page brief (JSON fields, no hallucinations) ----
export async function gptProspectAccountBrief({ profile = {}, inputs = {} } = {}) {

  await ensureSettingsLoaded();
  

  const {
    responsibilities = "",    // free text ok
    insights = [],            // [], bullets ok
    news = [],                // can be [{title,summary,url}] or strings
    financial = [],
    background = [],
    fit = {}                  // { badge, summary, recommendedAction }
  } = inputs || {};

  const system = [
    "You are an assistant that generates concise, sales-ready prospect and account briefs.",
    "Your goal: produce a 2-page document (Page 1: Prospect Intel, Page 2: Account Intel) to help a sales rep personalize outreach and prep discovery.",
    "Rules:",
    "- Keep each section short, scannable, relevant.",
    "- Use bullet points wherever possible.",
    "- Do NOT invent facts. If data is missing, leave the field empty or [].",
    "- Output strictly JSON with the fields shown below. No markdown."
  ].join("\n");

  const userPayload = {
    profile: {
      prospect_name: profile.name || "",
      prospect_title: profile.role || "",
      prospect_company: profile.company || "",
      prospect_location: profile.location || ""
    },
    signals: {
      responsibilities,
      insights,
      news,
      financial,
      background,
      fit
    },
    template_keys: {
      page1: {
        prospect_role_summary: true,
        prospect_experience: true,
        prospect_skills: true,
        prospect_connections_or_activity: true,
        hooks: true
      },
      page2: {
        company_overview: true,
        company_recent_news: true,
        company_challenges: true,
        company_tech_stack: true,
        company_metrics: true,
        company_sales_opportunity: true,
        discovery_questions: true
      }
    }
  };

  const user = `
Github code: You are an assistant that generates concise, sales-ready prospect and account briefs.

Guidelines:
- Keep each section short, scannable, and relevant.
- Use bullet points wherever possible.
- Do not invent facts. Only use the provided input data.
- If data is missing, leave the section blank (do not hallucinate).
- Output should be formatted in JSON with fields below.

### Page 1: Prospect Intel
- Name: {{prospect_name}}
- Title & Company: {{prospect_title}}, {{prospect_company}}
- Location: {{prospect_location}}
- Summary of Role: {{prospect_role_summary}}
- Career Highlights: {{prospect_experience}}
- Skills & Interests: {{prospect_skills}}
- Conversation Hooks: {{prospect_connections_or_activity}}
- Personalization Angles (AI-generated hooks for outreach): {{hooks}}

### Page 2: Account Intel
- Company Overview: {{company_overview}}
- Strategic Moves / News: {{company_recent_news}}
- Pain Points / Challenges: {{company_challenges}}
- Current Tools / Tech Stack: {{company_tech_stack}}
- Relevant Metrics: {{company_metrics}}
- Opportunity for Us (Sales Angle): {{company_sales_opportunity}}
- Suggested Discovery Questions: {{discovery_questions}}

Return JSON strictly:
{
  "page1": {
    "prospect_name": "",
    "prospect_title": "",
    "prospect_company": "",
    "prospect_location": "",
    "prospect_role_summary": "",
    "prospect_experience": [],
    "prospect_skills": [],
    "prospect_connections_or_activity": [],
    "hooks": []
  },
  "page2": {
    "company_overview": "",
    "company_recent_news": [],
    "company_challenges": [],
    "company_tech_stack": [],
    "company_metrics": "",
    "company_sales_opportunity": "",
    "discovery_questions": []
  }
}

Input JSON:
${JSON.stringify(userPayload)}
`.trim();

  const out = await callOpenAIJSON({
    system,
    user,
    parseFallback: {
      page1: {
        prospect_name: profile.name || "",
        prospect_title: profile.role || "",
        prospect_company: profile.company || "",
        prospect_location: profile.location || "",
        prospect_role_summary: "",
        prospect_experience: [],
        prospect_skills: [],
        prospect_connections_or_activity: [],
        hooks: []
      },
      page2: {
        company_overview: "",
        company_recent_news: [],
        company_challenges: [],
        company_tech_stack: [],
        company_metrics: "",
        company_sales_opportunity: "",
        discovery_questions: []
      }
    }
  });

  return out;
}


export async function gptChatbotReply({ ctx = {}, history = [], collected = {} } = {}) {


  const vendor = await readVendorFromStorage();

  // --- Minimal vendor guard (chat replies)
if (!vendor?.name || !String(vendor.name).trim()) {
  return {
    reply: "No vendor profile found — please set at least your company in Vendor Profile.",
    followups: ["Open Vendor Profile", "What info do you need from me?"],
    updates: {}
  };
}


  if (DEBUG_LOGS) console.log("[DBG] CHAT vendor:", vendor, "ctx:", ctx);


  // Lawrence drives toward the same 2-page brief used by the overlay.
  // He sees what we already scraped (ctx) + what we've already collected in chat (collected) + last ~14 turns.
  const system = [
    "You are Lawrence — a proactive Jarvis/FRIDAY-style sales copilot embedded on LinkedIn. Call the operator 'Boss'.",
    "Clearly separate: OUR COMPANY (the seller) vs THEIR COMPANY (the LinkedIn target).",
    "OUR COMPANY (seller): " + (vendor.name || "—") + " — " + (vendor.pitch || ""),
    "Vendor value props: " + ((vendor.valueProps || []).slice(0,5).join("; ") || "—"),
    "Vendor outcomes: " + ((vendor.outcomes || []).slice(0,5).join("; ") || "—"),
    "Industry hint: " + (vendor.industryHint || "—"),
    "THEIR COMPANY (prospect): comes from ctx.company.",
    "Goal: answer the user’s question directly using scraped profile (ctx) and the vendor JSON. Only ask at most one short follow-up if their question truly cannot be answered without it.",
    "Rules:",
    "- NEVER invent facts. Prefer answering with available info; only ask one precise follow-up if essential.",
    "- Use ctx.name/role/company/location when present.",
    "- Keep answers sales-useful (crisp bullets or a short paragraph).",
    "- Suggest at most 3 quick-actions as FOLLOWUPS.",
    "- Plain text only. No Markdown, no asterisks. Use short paragraphs and line breaks for bullets.",
    'Return STRICT JSON only: {"reply":"...","followups":["..."],"updates":{}}.'
  ].join("\n");



  const user = JSON.stringify({
  ctx,
  collected,
  vendor: {
    name: vendor.name,
    pitch: vendor.pitch,
    valueProps: vendor.valueProps,
    outcomes: vendor.outcomes,
    customerExamples: vendor.customerExamples,
    industryHint: vendor.industryHint
  },
  history
});


    const out = await callOpenAIJSON({
    system,
    user,
    parseFallback: {
      reply: "Ask me anything about this person or their company — I’ll answer directly using profile + our vendor context.",
      followups: [
        "Show recent company news",
        "Summarize responsibilities",
        "What are their current challenges?"
      ],
      updates: {}
    }
  });


  return {
    reply: (out.reply || "").trim(),
    followups: Array.isArray(out.followups) ? out.followups.filter(Boolean).slice(0, 3) : [],
    updates: (typeof out.updates === "object" && out.updates) ? out.updates : {}
  };
}







export async function runEnrichmentPrompt({ name, role, company, location, backgroundList = [], posts = [] }) {
  const prompt = `
You are a deterministic B2B prospect analyst.

INPUTS (immutable facts)
- Prospect:
  • Name: ${name}
  • Role: ${role}
  • Company: ${company}
  • Location: ${location || 'unknown'}
- Background (up to 3 lines):
${backgroundList.map((x,i)=>`  ${i+1}. ${x}`).join('\n')}
- Recent posts (up to 6 slices):
${posts.map((x,i)=>`  ${i+1}. ${String(x || '').slice(0,200)}`).join('\n')}

VENDOR CONTEXT (ground truth; do NOT ask user for these)
Provided in the SYSTEM message as a JSON block (name, website, pitch, value_props, outcomes, personas, pains, integrations, proof_points, case_studies, tone, cta_preference, booking_url, signature, industry).
Use it precisely. If some vendor fields are missing, state that briefly in "reasons" and proceed conservatively.

TASK
Assess fit between the PROSPECT and the VENDOR offering. Tie your assessment to vendor personas, pains, integrations, and proof points whenever possible.

STRICT RULES
- Output JSON ONLY (no extra text).
- "fit_badge" must be one of: "High" | "Medium" | "Low".
- "fit_summary" ≤ 420 chars, plain text, no lists, no emojis.
- "recommended_action" ≤ 120 chars, imperative voice, vendor-aware (CTA tone may reflect vendor.tone).
- "reasons" is an array of 1–4 terse items; each must cite at least one of:
  persona | pain | integration | proof_point (use these exact tokens).
- If data is thin/missing, be conservative ("Medium" or "Low") and include a reason noting the gap.

OUTPUT JSON SCHEMA
{
  "fit_summary": string,
  "fit_badge": "High"|"Medium"|"Low",
  "recommended_action": string,
  "responsibilities": string,            // one paragraph; <= 600 chars
  "insights": string[],                  // up to 3 items; each <= 100 chars
  "news": [{"title": string, "url": string}], // 0–3 items; may be empty
  "financial": string[],                 // up to 3 high-level items; may be empty
  "reasons": string[]                    // 1–4 items citing persona|pain|integration|proof_point
}
`.trim();

  const aiOut = await callOpenAIJSON({
    temperature: 0.15,
    system: 'You are a precise, deterministic B2B prospect analyst. Vendor JSON in system is ground truth; do not ask user for vendor fields.',
    user: prompt,
    parseFallback: {}
  });

  return aiOut;
}
